**  CAev CA Emitter Vendor
**  
**  May 19, 2017, by Pilla
**


** HOW TO INSTALL

Place the caemitter_pilla.agents file in your \agents 

** REDISTRIBUTION

You're free to use this work and make variations/alterations/prettier sprites/use the code/do whatever you fancy.
No need to ask.
Please do not rehost this file except if the link on CCaves doesn't work anymore.